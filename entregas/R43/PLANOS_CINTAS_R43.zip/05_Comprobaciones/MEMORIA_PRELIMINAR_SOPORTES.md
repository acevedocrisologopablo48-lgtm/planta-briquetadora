# Predimensionado preliminar de soportes de cintas R43

Fecha: 11/11/2026. Seleccion de modelado: **IPE 100 uniforme**, 100 x 55 mm, alma 4,1 mm, alas 5,7 mm, 8,1 kg/m. Acero S235 supuesto; debe confirmarse con certificado. Esta memoria no constituye aprobacion estructural, verificacion normativa ni autorizacion de fabricacion.

## Geometria leida del modelo

Lectura independiente de allParts y supportSchedulesR43 sobre r43.json, sincronizado solo en memoria. Columna mas alta: C02 A4, **2.573,96 mm**; asiento 2.636,76 mm. Luz entre columnas maxima: 820 mm; corte de cabezal 900 mm. Separacion maxima entre porticos: C04, 3.994,52 mm. Longitud tributaria maxima por puntos medios: C07 A2, 3,44697 m. Para el portico mas alto C02 A4 corresponde 2,11348 m. Las longitudes tributarias de cada cinta estan en el JSON.

El modelo actual tenia cabezal tubular de 50,8 mm; mantener su cara superior al instalar IPE100 acorta las columnas 49,2 mm. Aqui se conserva la longitud anterior mayor, 2,574 m, por conservadurismo.

## Cargas e idealizacion

Se adopta una cota provisional de **100 kg/m conjuntos** de transportador y material: q = 0,981 kN/m. No es una masa medida ni una carga deducida de capacidad de produccion. Se agrega peso propio de cabezal y columnas. La envolvente vertical multiplica todo por 1,5; la accion horizontal por columna es 2% de su carga vertical de envolvente. Se reparte verticalmente 50/50 entre dos columnas. La eleccion es independiente de la cifra historica de 15 t/h. Las masas reales y acumulaciones deben comprobarse contra la cota adoptada.

Columnas idealizadas como voladizos con base empotrada, eje debil libre, K = 2; no se acredita arriostramiento ni accion de portico. E = 210.000 MPa, fy = 235 MPa. Para rigidez se adopta L/300 = 8,58 mm como criterio preliminar propio, no como limite universal de una norma. Se usa la misma envolvente mayorada para esa criba, de modo conservador.

Cabezal simplemente apoyado a 820 mm; se combina conservadoramente esa luz maxima con la tributacion maxima de 3,44697 m, aunque pertenecen a distintos porticos. La carga se concentra en centro de luz e incluye peso de cabezal de 900 mm.

## Metodo y resultados

No se aplica ASD AISC. Se usa Euler, una reduccion de pandeo tipo EN 1993 curva b (alpha = 0,34, gammaM1 = 1), y amplificacion simplificada de segundo orden. La interaccion N/Nb + M2/(Wz fy) es solo una criba elastica lineal; no reemplaza la interaccion normativa de una barra comprimida y flectada ni el analisis global.

Ecuaciones: Ncr = pi² E Iz/(K L)²; lambda = raiz(A fy/Ncr); phi = 0,5[1 + 0,34(lambda - 0,2) + lambda²]; chi = 1/[phi + raiz(phi² - lambda²)]; Nb = chi A fy; M1 = H L; M2 = M1/[1 - N/Ncr]; delta1 = H L³/(3 E Iz); delta2 = delta1/[1 - N/Ncr].

| Resultado en C02 A4, L = 2,574 m | IPE 80 | IPE 100 |
|---|---:|---:|
| Masa, kg/m | 6,0 | 8,1 |
| Iz debil, cm4 | 8,49 | 15,92 |
| Carga por columna N, kN | 1.822 | 1.915 |
| H por columna, N | 36.44 | 38.31 |
| Ncr Euler K=2, kN | 6.64 | 12.45 |
| Nb referencia curva b, kN | 6.23 | 11.56 |
| Momento primer orden, kNm | 0.094 | 0.099 |
| Momento amplificado, kNm | 0.129 | 0.117 |
| Amplificador aproximado | 1.378 | 1.182 |
| Desplazamiento primer orden, mm | 11.62 | 6.51 |
| Desplazamiento segundo orden, mm | 16.01 | 7.70 |
| Criba N/Nb + M2/(Wz fy) | 0.441 | 0.251 |

En esta idealizacion, IPE80 tiene reserva de resistencia, pero su desplazamiento amplificado 16,01 mm supera el criterio preliminar 8,58 mm. IPE100 da 7,70 mm. Esto sustenta **IPE100 como seleccion preliminar uniforme**; el IPE80 requeriria demostrar arriostramiento y rigidez suficiente. El margen de rigidez de IPE100 exige confirmar cargas y uniones.

| Cabezal: envolvente conservadora P centrada, luz 820 mm | IPE 80 | IPE 100 |
|---|---:|---:|
| P incluida masa del cabezal, kN | 5.152 | 5.179 |
| M=P l/4, kNm | 1.056 | 1.062 |
| Tension elastica eje fuerte, MPa | 52.74 | 31.05 |
| Flecha P l³/(48 E Iy), mm | 0.352 | 0.166 |

La resistencia y flecha vertical del cabezal no gobiernan esta comparacion. No se ha comprobado pandeo lateral torsional: carga y asiento deben detallarse sobre el alma, con restriccion apropiada del ala comprimida.

## Comparacion y limites

W4x13 pesa aproximadamente 19,3 kg/m; IPE80, 6,0 kg/m; IPE100, 8,1 kg/m. IPE100 reduce aproximadamente 58% de masa frente a W4x13 y conserva una geometria comercial compacta. No se demuestra equivalencia estructural entre familias mediante esta comparacion de masas.

No incluye sismo, viento, impacto, atasco, arranque/parada, fatiga ni vibracion; tampoco anclajes, placas base, hormigon, soldaduras, pernos o rigidez real de las uniones. No incluye estructuras de maquinas, tolvas, secador, pasarelas ni soportes de C03. No incluye cargas puntuales de accionamientos ni mantenimiento, salvo demostracion de que caben en la cota de carga asumida. Bases articuladas sin arriostramiento pueden formar un mecanismo; la idealizacion K=2 requiere empotramiento real capaz de tomar momento. El calculo de estabilidad del conjunto y el detalle de arriostramientos quedan pendientes.

Propiedades geometricas verificadas en [ArcelorMittal Orange Book](https://orangebook.arcelormittal.com/node/6) y [programa comercial ArcelorMittal 2024-1](https://sections.arcelormittal.com/repository2/Sections/Sections_MB_ArcelorMittal_FR_EN_DE.pdf). Los valores de resistencia del Orange Book S355 no se usan: aqui se supone fy = 235 MPa.

## Barrido de todos los porticos modificados: IPE100

Se comprobaron 19 porticos y 38 columnas, incluidos C04. Cada fila usa sus propias longitudes de columna y cabezal, luz y longitud tributaria. Las dos columnas de cada portico tienen igual longitud; no se reemplazan las alturas por una altura tipica. Se mantiene la geometria previa de tubo de 50,8 mm, mayor que la longitud de columna necesaria al mantener asiento con IPE100. La carga, K=2 y demas hipotesis permanecen iguales.

| Portico | L columna mm | Lt m | Luz cabezal mm | N columna kN | N/Ncr | delta1 mm | delta2 mm | delta2/(L/300) | Criba interaccion | M cabezal kNm | Flecha cabezal mm |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| C01 A1 | 127.90 | 2.240 | 820.0 | 1.717 | 0.000 | 0.00 | 0.00 | 0.002 | 0.010 | 0.698 | 0.109 |
| C01 A2 | 690.14 | 2.803 | 820.0 | 2.198 | 0.013 | 0.14 | 0.15 | 0.063 | 0.041 | 0.867 | 0.135 |
| C01 A3 | 1483.27 | 2.507 | 820.0 | 2.075 | 0.055 | 1.35 | 1.43 | 0.289 | 0.111 | 0.778 | 0.121 |
| C01 A4 | 1972.92 | 2.925 | 820.0 | 2.441 | 0.115 | 3.74 | 4.23 | 0.642 | 0.207 | 0.904 | 0.141 |
| C02 A1 | 407.48 | 2.326 | 820.0 | 1.814 | 0.004 | 0.02 | 0.02 | 0.018 | 0.020 | 0.724 | 0.113 |
| C02 A2 | 1171.06 | 2.702 | 820.0 | 2.181 | 0.036 | 0.70 | 0.72 | 0.186 | 0.082 | 0.837 | 0.131 |
| C02 A3 | 1975.80 | 2.353 | 820.0 | 2.021 | 0.096 | 3.11 | 3.44 | 0.522 | 0.170 | 0.732 | 0.114 |
| C02 A4 | 2573.96 | 2.113 | 820.0 | 1.915 | 0.154 | 6.51 | 7.70 | 0.897 | 0.251 | 0.660 | 0.103 |
| C04 A1 | 204.20 | 2.163 | 420.0 | 1.645 | 0.001 | 0.00 | 0.00 | 0.004 | 0.012 | 0.340 | 0.014 |
| C04 A2 | 1243.94 | 2.139 | 420.0 | 1.752 | 0.033 | 0.67 | 0.70 | 0.168 | 0.072 | 0.337 | 0.014 |
| C06 A1 | 122.92 | 1.621 | 360.0 | 1.232 | 0.000 | 0.00 | 0.00 | 0.001 | 0.007 | 0.219 | 0.007 |
| C06 A2 | 347.92 | 1.801 | 360.0 | 1.392 | 0.002 | 0.01 | 0.01 | 0.010 | 0.014 | 0.243 | 0.007 |
| C06 A3 | 475.98 | 1.170 | 360.0 | 0.942 | 0.003 | 0.02 | 0.02 | 0.013 | 0.012 | 0.159 | 0.005 |
| C07 A1 | 207.24 | 2.218 | 360.0 | 1.682 | 0.001 | 0.00 | 0.00 | 0.004 | 0.012 | 0.298 | 0.009 |
| C07 A2 | 1055.12 | 3.447 | 360.0 | 2.687 | 0.036 | 0.63 | 0.65 | 0.186 | 0.088 | 0.461 | 0.014 |
| C07 A3 | 1864.75 | 3.094 | 360.0 | 2.524 | 0.106 | 3.26 | 3.65 | 0.588 | 0.195 | 0.414 | 0.012 |
| C08 A1 | 271.98 | 1.539 | 589.2 | 1.203 | 0.001 | 0.00 | 0.00 | 0.005 | 0.010 | 0.345 | 0.028 |
| C08 A2 | 816.09 | 1.899 | 589.2 | 1.533 | 0.012 | 0.17 | 0.17 | 0.062 | 0.035 | 0.423 | 0.034 |
| C08 A3 | 1318.78 | 1.510 | 589.2 | 1.306 | 0.028 | 0.60 | 0.61 | 0.140 | 0.058 | 0.339 | 0.027 |

Maximo delta2/(L/300) = **0.897**, en C02 A4; maximo N/Ncr = **0.154**, en C02 A4. Todos los porticos examinados quedan por debajo del criterio de desplazamiento adoptado bajo esta idealizacion preliminar. Esto no amplía el alcance a C03 ni a estructuras de maquinas, y no constituye aprobacion estructural. La tabla anterior del cabezal combinaba extremos de diferentes porticos y sigue siendo una envolvente mas conservadora que las comprobaciones fila por fila.
